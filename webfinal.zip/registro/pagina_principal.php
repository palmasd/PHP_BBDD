<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixel coffee</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="animations.css"> 
</head>
<body>

<div class="intro">
        <h1 class="intro-title">Pixel coffee</h1>
        <form action="menu.php" method="post" class="intro-buttons">
            <button type="submit" class="intro-button">Menú</button>
        </form>
        <form action="ubicacion.php" method="post" class="intro-buttons">
            <button type="submit" class="intro-button">Ubicación</button>
        </form>
        <form action="contacto.php" method="post" class="intro-buttons">
            <button type="submit" class="intro-button">Contacto</button>
        </form>
        <form action="ofertas.php" method="post" class="intro-buttons">
            <button type="submit" class="intro-button">Ofertas y promociones</button>
        </form>
        
    </div>

   
    <footer>
        <p>&copy; 2024 Pixel Coffee. Todos los derechos reservados.</p>
    </footer>

</body>
</html>
