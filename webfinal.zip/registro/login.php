<?php
$errores = '';
$enviado = true;


if (isset($_POST['submit'])) {
    $Nombre = $_POST['Nombre'];
    $Apellido = $_POST['Apellido'];
    $Email = $_POST['Email'];
    $Contraseña = $_POST['Contraseña'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $Nombre = $_POST['Nombre'];
        $Apellido = $_POST['Apellido'];
        $Email = $_POST['Email'];
        $Contraseña = md5($_POST['Contraseña']);
    


        $conexion = new mysqli('localhost', 'root', '', 'prueba_datos');

        $sql1 = " SELECT * FROM usuarios Where Nombre = '$Nombre'";
        $connect = $conexion->query($sql1);

            if ($connect->num_rows > 0) {
               $row = $connect->fetch_assoc();
               if (!password_verify($Contraseña, $row['Contraseña'])) {
                    header("Location: pagina_principal.php");
                    exit();
                }
            } else {
                echo "falta los datos <br />";
            }
        }

    
    }

require 'login.view.php';
?>
