<?php
include('connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se cargó un archivo
    if (isset($_FILES["imagen"]) && $_FILES["imagen"]["error"] == 0) {
        // Preparar los datos del archivo
        $imagen_nombre = $_FILES["imagen"]["name"];
        $imagen_tipo = $_FILES["imagen"]["type"];
        $imagen_tamano = $_FILES["imagen"]["size"];
        $imagen_temporal = $_FILES["imagen"]["tmp_name"];

        // Leer el contenido del archivo
        $imagen_contenido = addslashes(file_get_contents($imagen_temporal));

        // Insertar la imagen en la base de datos
        $sql = "INSERT INTO imagenes (nombre, imagen) VALUES ('$imagen_nombre', '$imagen_contenido')";
        if ($conn->query($sql) === TRUE) {
            echo "Imagen guardada correctamente en la base de datos.";
            header("location: menu.php");
        } else {
            echo "Error al guardar la imagen: " . $conn->error;
        }
    } else {
        echo "Error: No se ha seleccionado ninguna imagen o ocurrió un error al cargarla.";
    }


    
}

// Cerrar conexión
$conn->close();
?>


/*
if(isset($_POST['Guardar'])){
    $imagen = $_FILES['imagen']['name'];

if(isset($imagen) && $imagen != ""){
        $tipo = $_FILES['imagen']['type'];
        $temp  = $_FILES['imagen']['tmp_name'];  
        
if( !((strpos($tipo,'gif') || strpos($tipo,'jpeg') || strpos($tipo,'webp')))){
            $_SESSION['mensaje'] = 'solo se permite archivos jpeg, gif, webp';
            $_SESSION['tipo'] = 'danger';
            header("location: menu.php");
         }else{
        $query = "INSERT INTO imagenes(imagen) values('$imagen')";
        $resultado = mysqli_query($conn,$query);
                if($resultado){
                     move_uploaded_file($temp,'imagenes/'.$imagen);   
                    $_SESSION['mensaje'] = 'se ha subido correctamente';
                    $_SESSION['tipo'] = 'success';
                    header("location: menu.php");
                }else{
                    $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
                    $_SESSION['tipo'] = 'danger';
                }
              }

         }

}
*\
    
