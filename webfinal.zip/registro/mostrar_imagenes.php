  <?php
// Incluir el archivo de conexión
include ('connect.php');

// Obtener las imágenes de la base de datos
$sql = "SELECT nombre, imagen FROM imagenes WHERE nombre= sandwich.jpg";
$resultado = $conn->query($sql);

// Verificar si se encontraron imágenes
if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
        // Mostrar la imagen
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

// Cerrar conexión
$conn->close();
?>

