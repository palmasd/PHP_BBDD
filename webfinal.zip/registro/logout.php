<?php
// Inicia la sesión si aún no ha sido iniciada
session_start();

// Elimina todas las variables de sesión
session_unset();

// Destruye la sesión
session_destroy();

// Redirecciona a la página de inicio de sesión o a cualquier otra página deseada
header("Location: index.php");
exit();
?>
