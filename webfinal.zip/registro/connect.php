<?php
$servidor = "localhost"; // servidor de la base de datos
$usuario = "root"; // usuario de la base de datos
$base_de_datos = "prueba_datos"; // nombre de la base de datos

$conn = new mysqli('localhost', 'root', '', 'prueba_datos');




if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>