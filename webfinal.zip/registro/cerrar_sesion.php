<?php 
 
    session_destroy();
    header('index.php');
?>