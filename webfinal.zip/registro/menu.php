<?php 
  include('connect.php');
  $query = "select * from imagenes";
  $resultado = mysqli_query($conn,$query);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixel Coffee - Menú</title>
    <link rel="stylesheet" href="styles.css">

</head>
<body>

<header>
        <h1>Pixel coffee</h1>
    </header>

<nav>
        <a href="pagina_principal.php">Inicio</a> |
        <a href="ubicacion.php">Ubicación</a> |
        <a href="contacto.php">Contacto</a>
        <a href="ofertas.php">Ofertas y promociones</a>
    </nav>

              <!-- Este es un ejemplo básico de un botón de cierre de sesión -->
<form action="logout.php" method="post">
<button id="logout-btn" type="submit">Cerrar Sesión</button>
</form>

<div class="container">
       <div class="col-lg-7">
         <h1>Nuestro menu</h1>
         <form action="subir.php" method="post" enctype="multipart/form-data"></form>
         

         <li>Sándwich de jamón y queso - 3.00€</li>
<?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'sandwich.jpg'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
   
        <li>Bocadillos de bacon y queso - 4.50€</li>
<?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'baconyqueso'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>

          <li>Bocadillos/sándwich de lomo y queso - 4.50€</li>
          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'lomo'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>

          <li>Bocadillos de tortilla - 4.00€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'tortilla'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Bocadillos de jamón serrano con tomate - 4.50€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'jamonytomate'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>

          <li>Cafés - 2.00€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'cafes'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>

          <li>Refrescos (refill) - 4.99€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'refil'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Refresco sin refill - 2.00€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'refresco'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Zumo de naranja - 2.50€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'zumo'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Croissant a la plancha - 3.50€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'plancha'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Croissant con chocolate - 3.50€</li>
          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'chocolate'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Magdalenas de chocolate - 3.00€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'magdalenas'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Galletas (6 UND) - 3.99€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'galletas'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Cheesecake de fresa - 4.75€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'cheesescake'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Brownie de chocolate - 5.79€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'brownie'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Batido de fruta - 3.99€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'batidofruta'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Finger de pollo (6 und) - 3.75€ / (9 und) - 5.00€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'fingers'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Nachos con queso - 3.75€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'nachosqueso'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Nachos con guacamole - 4.79€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'nachosguacamole'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Cheesebacon fries - 4.79€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'cheesebaconfries.jpg'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Nuggets de pollo - 3.75€</li>

          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'nuggets.jpg'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          <li>Empanadillas - 2.50€</li>
          <?php $sql = "SELECT nombre, imagen FROM imagenes WHERE nombre = 'empanadillas.jpg'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    // Iterar sobre cada imagen
    while ($fila = $resultado->fetch_assoc()) {
        $nombre = $fila['nombre'];
        $imagen_contenido = $fila['imagen'];
        
     
        echo '<img src="data:image/jpeg;base64,'.base64_encode($imagen_contenido).'" />';
    }
} else {
    echo "No se encontraron imágenes en la base de datos.";
}

?>
          </div>
          
    <footer>
        <p>&copy; 2024 Pixel Coffee. Todos los derechos reservados.</p>
    </footer>


</body>
</html>
