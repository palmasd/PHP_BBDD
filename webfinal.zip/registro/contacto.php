<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixel Coffee - Contacto</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <header>
        <h1>Pixel coffee</h1>
    </header>

    <nav>
        <a href="pagina_principal.php">Inicio</a> |
        <a href="menu.php">Menú</a> |
        <a href="ubicacion.php">Ubicación</a> |
        <a href="ofertas.php">Ofertas y promociones</a>
    </nav>

    <section id="contacto">
        <h2>Contacto</h2>
        <p>¡Estamos aquí para ayudarte! Contáctanos:</p>
        <p>Email: info@pixelcofee.com</p>
        <p>Teléfono: 123-456-7890</p>
    </section>

    <footer>
        <p>&copy; 2024 Pixel Coffee. Todos los derechos reservados.</p>
    </footer>

</body>
</html>
