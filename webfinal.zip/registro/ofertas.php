<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixel Coffee - Ofertas y Promociones</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <header>
        <h1>Pixel coffee</h1>
    </header>

    <nav>
        <a href="pagina_principal.php">Inicio</a> |
        <a href="menu.php">Menú</a> |
        <a href="ubicacion.php">Ubicación</a> |
        <a href="contacto.php">Contacto</a>
    </nav>

    <section id="ofertas">
        <h2>Ofertas y Promociones</h2>
        <p>¡Descubre nuestras increíbles ofertas y promociones!</p>
        <!-- Puedes agregar detalles de ofertas y promociones aquí -->
    </section>

    <footer>
        <p>&copy; 2024 Pixel Coffee. Todos los derechos reservados.</p>
    </footer>

</body>
</html>
