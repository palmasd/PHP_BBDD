<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixel Coffee - Ubicación</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <header>
        <h1>Pixel coffee</h1>
    </header>

    <nav>
        <a href="pagina_principal.php">Inicio</a> |
        <a href="menu.php">Menú</a> |
        <a href="contacto.php">Contacto</a>
        <a href="ofertas.php">Ofertas y promociones</a>
    </nav>

    <section id="ubicacion">
        <h2>Ubicación</h2>
        <p>Estamos ubicados en el corazón de la ciudad. ¡Ven a visitarnos!</p>
        <!-- Puedes agregar un mapa o detalles de ubicación aquí -->
    </section>

    <footer>
        <p>&copy; 2024 Pixel Coffee. Todos los derechos reservados.</p>
    </footer>

</body>
</html>
